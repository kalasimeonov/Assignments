package test1;

import org.junit.Assert;
import org.junit.Test;
import source1.Month;
import source1.RainfallYear;

public class RainfallYearTest {
    public RainfallYearTest() {
    }

    @Test
    public void testConstruction() {
        RainfallYear rainfallYear = new RainfallYear(2009, new double[]{0.0D, 1.0D, 2.0D, 3.0D, 4.0D, 5.0D, 6.0D, 7.0D, 8.0D, 9.0D, 10.0D, 11.0D});
        Assert.assertEquals("Incorrect year", 2009L, (long)rainfallYear.getYear());

        for(int i = 0; i < 12; ++i) {
            Assert.assertEquals("Incorrect rainfall", (double)i, rainfallYear.getRainfallMonth(Month.values()[i]), 0.0D);
            System.out.println(Month.values()[i] + ": " + i + " == " + rainfallYear.getRainfallMonth(Month.values()[i]));
        }

    }

    @Test
    public void testMeanRainfall() {
        RainfallYear rainfallYear = new RainfallYear(2009, new double[]{0.0D, 1.0D, 2.0D, 3.0D, 4.0D, 5.0D, 6.0D, 7.0D, 8.0D, 9.0D, 10.0D, 11.0D});
        double expectedMean = 5.5D;
        Assert.assertEquals("Incorrect mean", expectedMean, rainfallYear.calculateMeanRainfall(), 0.0D);
    }
}
