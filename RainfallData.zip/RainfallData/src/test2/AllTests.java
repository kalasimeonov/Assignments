package test2;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({RainfallYearTest.class})
public class AllTests {
    public AllTests() {
    }
}