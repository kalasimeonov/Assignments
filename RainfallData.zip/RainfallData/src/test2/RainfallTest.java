package test2;

import org.junit.Assert;
import org.junit.Test;
import source2.Month;
import source2.Rainfall;
import source2.RainfallYear;

public class RainfallTest {
    public RainfallTest() {
    }

    @Test
    public void testConstruction() {
        RainfallYear[] temp = new RainfallYear[]{new RainfallYear(1914, new double[]{50.9D, 87.0D, 115.8D, 32.3D, 47.1D, 56.6D, 97.1D, 63.9D, 48.1D, 62.4D, 110.3D, 190.8D}), new RainfallYear(1915, new double[]{105.3D, 129.0D, 36.2D, 37.3D, 64.3D, 33.3D, 123.0D, 76.2D, 39.4D, 71.4D, 73.5D, 182.7D}), new RainfallYear(1916, new double[]{58.6D, 129.4D, 97.9D, 47.9D, 70.7D, 63.7D, 51.3D, 89.2D, 54.8D, 142.1D, 110.1D, 90.4D}), new RainfallYear(1917, new double[]{58.2D, 30.9D, 67.0D, 55.0D, 61.7D, 65.7D, 64.3D, 172.8D, 54.8D, 130.7D, 61.7D, 43.1D}), new RainfallYear(1918, new double[]{90.1D, 67.8D, 39.2D, 56.0D, 57.7D, 31.5D, 110.1D, 60.7D, 186.2D, 72.1D, 67.3D, 123.2D}), new RainfallYear(1919, new double[]{117.7D, 71.4D, 122.1D, 62.6D, 26.6D, 37.0D, 58.3D, 79.1D, 53.7D, 65.4D, 71.2D, 143.9D}), new RainfallYear(1920, new double[]{111.3D, 49.9D, 91.0D, 119.0D, 75.2D, 61.9D, 133.1D, 48.0D, 69.0D, 67.8D, 45.3D, 91.4D}), new RainfallYear(1921, new double[]{110.5D, 8.7D, 64.5D, 32.6D, 47.8D, 10.3D, 31.0D, 98.2D, 38.5D, 51.7D, 65.2D, 80.4D}), new RainfallYear(1922, new double[]{107.2D, 95.0D, 69.6D, 77.4D, 33.2D, 39.6D, 119.0D, 96.6D, 80.6D, 33.1D, 47.1D, 118.7D}), new RainfallYear(1923, new double[]{62.4D, 153.5D, 48.3D, 67.9D, 67.3D, 20.5D, 76.7D, 95.0D, 82.9D, 137.2D, 92.5D, 96.8D})};
        Rainfall rainfall = new Rainfall(temp);
        int[] years = rainfall.getYears();
        System.out.println(years.length);

        for(int i = 0; i < years.length; ++i) {
            Assert.assertEquals("Incorrect year", (long)(1914 + i), (long)years[i]);
        }

    }

    @Test
    public void testMonth() {
        RainfallYear[] temp = new RainfallYear[]{new RainfallYear(1914, new double[]{50.9D, 87.0D, 115.8D, 32.3D, 47.1D, 56.6D, 97.1D, 63.9D, 48.1D, 62.4D, 110.3D, 190.8D}), new RainfallYear(1915, new double[]{105.3D, 129.0D, 36.2D, 37.3D, 64.3D, 33.3D, 123.0D, 76.2D, 39.4D, 71.4D, 73.5D, 182.7D}), new RainfallYear(1916, new double[]{58.6D, 129.4D, 97.9D, 47.9D, 70.7D, 63.7D, 51.3D, 89.2D, 54.8D, 142.1D, 110.1D, 90.4D}), new RainfallYear(1917, new double[]{58.2D, 30.9D, 67.0D, 55.0D, 61.7D, 65.7D, 64.3D, 172.8D, 54.8D, 130.7D, 61.7D, 43.1D}), new RainfallYear(1918, new double[]{90.1D, 67.8D, 39.2D, 56.0D, 57.7D, 31.5D, 110.1D, 60.7D, 186.2D, 72.1D, 67.3D, 123.2D}), new RainfallYear(1919, new double[]{117.7D, 71.4D, 122.1D, 62.6D, 26.6D, 37.0D, 58.3D, 79.1D, 53.7D, 65.4D, 71.2D, 143.9D}), new RainfallYear(1920, new double[]{111.3D, 49.9D, 91.0D, 119.0D, 75.2D, 61.9D, 133.1D, 48.0D, 69.0D, 67.8D, 45.3D, 91.4D}), new RainfallYear(1921, new double[]{110.5D, 8.7D, 64.5D, 32.6D, 47.8D, 10.3D, 31.0D, 98.2D, 38.5D, 51.7D, 65.2D, 80.4D}), new RainfallYear(1922, new double[]{107.2D, 95.0D, 69.6D, 77.4D, 33.2D, 39.6D, 119.0D, 96.6D, 80.6D, 33.1D, 47.1D, 118.7D}), new RainfallYear(1923, new double[]{62.4D, 153.5D, 48.3D, 67.9D, 67.3D, 20.5D, 76.7D, 95.0D, 82.9D, 137.2D, 92.5D, 96.8D})};
        Rainfall rainfall = new Rainfall(temp);
        Assert.assertEquals("Incorrect mean rainfall for a month", 87.22D, rainfall.calculateMeanRainfallMonth(Month.JANUARY), 0.01D);
    }

    @Test
    public void testYear() {
        RainfallYear[] temp = new RainfallYear[]{new RainfallYear(1914, new double[]{50.9D, 87.0D, 115.8D, 32.3D, 47.1D, 56.6D, 97.1D, 63.9D, 48.1D, 62.4D, 110.3D, 190.8D}), new RainfallYear(1915, new double[]{105.3D, 129.0D, 36.2D, 37.3D, 64.3D, 33.3D, 123.0D, 76.2D, 39.4D, 71.4D, 73.5D, 182.7D}), new RainfallYear(1916, new double[]{58.6D, 129.4D, 97.9D, 47.9D, 70.7D, 63.7D, 51.3D, 89.2D, 54.8D, 142.1D, 110.1D, 90.4D}), new RainfallYear(1917, new double[]{58.2D, 30.9D, 67.0D, 55.0D, 61.7D, 65.7D, 64.3D, 172.8D, 54.8D, 130.7D, 61.7D, 43.1D}), new RainfallYear(1918, new double[]{90.1D, 67.8D, 39.2D, 56.0D, 57.7D, 31.5D, 110.1D, 60.7D, 186.2D, 72.1D, 67.3D, 123.2D}), new RainfallYear(1919, new double[]{117.7D, 71.4D, 122.1D, 62.6D, 26.6D, 37.0D, 58.3D, 79.1D, 53.7D, 65.4D, 71.2D, 143.9D}), new RainfallYear(1920, new double[]{111.3D, 49.9D, 91.0D, 119.0D, 75.2D, 61.9D, 133.1D, 48.0D, 69.0D, 67.8D, 45.3D, 91.4D}), new RainfallYear(1921, new double[]{110.5D, 8.7D, 64.5D, 32.6D, 47.8D, 10.3D, 31.0D, 98.2D, 38.5D, 51.7D, 65.2D, 80.4D}), new RainfallYear(1922, new double[]{107.2D, 95.0D, 69.6D, 77.4D, 33.2D, 39.6D, 119.0D, 96.6D, 80.6D, 33.1D, 47.1D, 118.7D}), new RainfallYear(1923, new double[]{62.4D, 153.5D, 48.3D, 67.9D, 67.3D, 20.5D, 76.7D, 95.0D, 82.9D, 137.2D, 92.5D, 96.8D})};
        Rainfall rainfall = new Rainfall(temp);
        Assert.assertEquals("Incorrect mean rainfall for a year", 80.19D, rainfall.calculateMeanRainfallYear(1914), 0.01D);
        Assert.assertEquals("Incorrect lowest mean annual rainfall", 53.28D, rainfall.calculateLowestMeanAnnualRainfall(), 0.01D);
        Assert.assertEquals("Incorrect highest mean annual rainfall", 83.84D, rainfall.calculateHighestMeanAnnualRainfall(), 0.01D);
    }
}