package source2;

public class Rainfall {
    private RainfallYear[] rainfallYears = null;

    public Rainfall(RainfallYear[] rainfallYears) {
        this.rainfallYears = rainfallYears;
    }

    public int[] getYears() {
        int[] getYears = new int[this.rainfallYears.length];

        for(int i = 0; i < this.rainfallYears.length; ++i) {
            getYears[i] = this.rainfallYears[i].getYear();
        }

        return getYears;
    }

    public double calculateHighestMeanAnnualRainfall() {
        double highest = 0.0D;

        for(int i = 0; i < this.rainfallYears.length; ++i) {
            if (this.rainfallYears[i].calculateMeanRainfall() > highest) {
                highest = this.rainfallYears[i].calculateMeanRainfall();
            }
        }

        return highest;
    }

    public double calculateLowestMeanAnnualRainfall() {
        double lowest = this.rainfallYears[0].calculateMeanRainfall();

        for(int i = 1; i < this.rainfallYears.length; ++i) {
            if (this.rainfallYears[i].calculateMeanRainfall() < lowest) {
                lowest = this.rainfallYears[i].calculateMeanRainfall();
            }
        }

        return lowest;
    }

    public double calculateMeanRainfallMonth(Month month) {
        double rainfallMonthTotal = 0.0;

        for(int i = 0; i < this.rainfallYears.length; ++i) {
            rainfallMonthTotal += this.rainfallYears[i].getRainfallMonth(month);
        }

        return (rainfallMonthTotal / this.rainfallYears.length);
    }

    public double calculateMeanRainfallYear(int year) {
        for(int i = 0; i < this.rainfallYears.length; ++i) {
            if (this.rainfallYears[i].getYear() == year) {
                return this.rainfallYears[i].calculateMeanRainfall();
            }
        }

        return 0.0D;
    }
}
