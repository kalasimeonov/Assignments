package source2;

public class RainfallYear {
    private int year = 0;
    private double[] rainfallMonths = null;

    public RainfallYear(int year, double[] rainfallMonths) {
        this.year = year;
        this.rainfallMonths = rainfallMonths;
    }

    public double calculateMeanRainfall() {
        double totalRainfall = 0.0D;

        for(int i = 0; i < 12; ++i) {
            totalRainfall += this.rainfallMonths[i];
        }

        return totalRainfall / 12;
    }

    public double getRainfallMonth(Month month) {
        switch(month) {
        case JANUARY:
            return this.rainfallMonths[0];
        case FEBRUARY:
            return this.rainfallMonths[1];
        case MARCH:
            return this.rainfallMonths[2];
        case APRIL:
            return this.rainfallMonths[3];
        case MAY:
            return this.rainfallMonths[4];
        case JUNE:
            return this.rainfallMonths[5];
        case JULY:
            return this.rainfallMonths[6];
        case AUGUST:
            return this.rainfallMonths[7];
        case SEPTEMBER:
            return this.rainfallMonths[8];
        case OCTOBER:
            return this.rainfallMonths[9];
        case NOVEMBER:
            return this.rainfallMonths[10];
        case DECEMBER:
            return this.rainfallMonths[11];
        default:
            throw new IllegalArgumentException("Incorrect month specified.");
        }
    }

    public int getYear() {
        return this.year;
    }
}
